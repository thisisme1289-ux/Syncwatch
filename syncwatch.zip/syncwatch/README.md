# SyncWatch

Watch videos together with near-zero internet usage.

## Modes

| Mode | Data per session | How it works |
|---|---|---|
| Local Sync | ~1-5 MB | Both load the same file locally. Only play/pause/seek is synced. |
| Upload & Watch | Same as streaming | Host uploads once. Guests stream from server. |
| Screen Share | 500MB+/hr | WebRTC screen capture. Fallback only. |

## Setup

### 1. Install dependencies
```bash
npm install
```

### 2. Configure environment
```bash
cp .env.example .env
# Edit .env if needed
```

### 3. Run
```bash
# Production
npm start

# Development (auto-reload)
npm run dev
```

Open http://localhost:3000

## Environment Variables

| Variable | Default | Description |
|---|---|---|
| PORT | 3000 | Server port |
| MAX_UPLOAD_MB | 2048 | Max video upload size in MB |
| ROOM_TTL_HOURS | 24 | Hours before empty rooms are cleaned up |
| NODE_ENV | production | Node environment |

## Project Structure

```
syncwatch/
├── server/
│   ├── index.js      Express + Socket.io server entry
│   ├── rooms.js      In-memory room store with TTL cleanup
│   ├── socket.js     All real-time WebSocket event handlers
│   └── upload.js     Multer-based video upload with range support
├── public/
│   ├── index.html    Single-page app with HTML templates
│   ├── css/
│   │   └── main.css  Full UI stylesheet
│   └── js/
│       ├── utils.js        Shared helpers (formatTime, toast, copyText)
│       ├── datacounter.js  Live bandwidth usage tracker
│       ├── room.js         Socket state manager and UI sync
│       ├── player.js       Video player controller
│       ├── screenshare.js  WebRTC screen share (host + guest)
│       └── app.js          Page router and main orchestrator
├── uploads/          Created automatically on first upload
├── package.json
└── .env.example
```

## Socket Events

### Client to Server
| Event | Payload | Description |
|---|---|---|
| join_room | { roomId, nickname, password?, hostToken? } | Join a room |
| playback_play | { roomId, timestamp } | Play video |
| playback_pause | { roomId, timestamp } | Pause video |
| playback_seek | { roomId, timestamp } | Seek to position |
| playback_rate | { roomId, rate } | Change playback speed |
| request_sync | { roomId } | Request current playback state |
| chat_message | { roomId, text } | Send chat message |
| quality_change | { roomId, quality } | Change quality (per-viewer) |
| settings_update | { roomId, settings } | Update room settings (host only) |
| transfer_host | { roomId, targetSocketId } | Transfer host role |
| ss_offer | { roomId, offer } | Screen share WebRTC offer (host) |
| ss_answer | { roomId, answer } | Screen share WebRTC answer (guest) |
| ss_ice | { roomId, candidate } | ICE candidate relay |
| ss_stopped | { roomId } | Host ended screen share |

### Server to Client
| Event | Payload | Description |
|---|---|---|
| room_joined | { full room state } | Sent to joining user |
| room_error | { message } | Join failure |
| user_joined | { socketId, nickname, isHost } | Broadcast |
| user_left | { socketId, nickname } | Broadcast |
| playback_play | { timestamp, by } | Broadcast |
| playback_pause | { timestamp, by } | Broadcast |
| playback_seek | { timestamp, by } | Broadcast |
| playback_rate | { rate, by } | Broadcast |
| sync_state | { playback } | Sent to requester only |
| chat_message | { nickname, text, ts } | Broadcast |
| settings_update | { settings } | Broadcast |
| host_transferred | { newHostId, newHostNickname } | Broadcast |
| media_ready | { url, filename } | Broadcast after upload |
| ss_offer | { offer } | Relayed to guests |
| ss_answer | { answer, from } | Relayed to host |
| ss_ice | { candidate, from } | Relayed bidirectionally |
| ss_stopped | (none) | Broadcast when host stops share |

## Data Model

### Room (in-memory)
```js
{
  id: UUID,
  code: "ABC123",        // 6-char readable code
  hostToken: UUID,       // only given to host at creation
  hostNickname: string,
  mode: "local" | "upload" | "screenshare",
  password: string | null,
  settings: {
    hostOnlyControl: bool,
    voiceEnabled: bool,
    videoEnabled: bool,
    chatEnabled: bool,
    dataSaver: bool,
    defaultQuality: "low" | "medium" | "high" | "source"
  },
  playback: {
    state: "playing" | "paused",
    timestamp: number,     // seconds
    rate: number,
    updatedAt: timestamp   // for drift compensation
  },
  media: null | { filename, storedName, url, size, uploadedAt },
  users: Map<socketId, { nickname, isHost, joinedAt }>,
  chat: [{ nickname, text, ts }],   // last 100 messages
  createdAt: timestamp,
  lastActivity: timestamp
}
```

## Limitations and Tradeoffs

### Upload mode — no transcoding
The server serves the original uploaded file. Quality selection is wired up on the client but without ffmpeg there is no actual resolution switching. To add this, install ffmpeg and generate 3 renditions on upload (480p, 360p, 240p). Each rendition can be served as a separate file and the quality selector switches the video src.

### Screen share — single offer
The current screen share implementation sends one broadcast offer. This works for one guest. For multiple guests simultaneously, you would need to create a separate RTCPeerConnection per guest and track them by socketId. This is architecturally simple to add but increases host upload bandwidth proportionally.

### Room persistence
Rooms are in-memory only. A server restart clears all rooms. For persistence, replace the RoomManager Map with Redis or a SQLite database.

### Uploaded files
Uploaded files are stored on disk in the uploads/ directory and are not automatically deleted when a room closes. Add a cleanup job that deletes files older than 24 hours, keyed to room.media.uploadedAt.

### TURN server
WebRTC screen share works peer-to-peer via STUN (stun.l.google.com). In restrictive networks or behind symmetric NAT, a TURN relay server is needed. Add TURN credentials to the ICE_SERVERS array in screenshare.js.
